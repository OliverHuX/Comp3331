import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.Math; 

public class PingClient {
    private static int MAXSIZE = 1024;

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.out.println("Required two arguments: Host and Port");
            return;
        }

        String ServerPort = args[1];
        InetAddress server = InetAddress.getByName(args[0]);
        DatagramSocket clientSocket = new DatagramSocket();
        clientSocket.setSoTimeout(1000);

        double AveRTT = 0, MaxRTT = 0, MinRTT = 0, totalRTT = 0;
        int count = 0;
        for(int i = 0; i < 15; i++) {
            Date time1 = new Date();
            double timeStampStart = time1.getTime();

            String pingMessage = time1.toString();
            
            DatagramPacket pingRequest = new DatagramPacket(pingMessage.getBytes(), pingMessage.length(), server, Integer.parseInt(ServerPort));

            clientSocket.send(pingRequest);
            byte[] receiveDate = new byte[MAXSIZE];
            DatagramPacket serverReply = new DatagramPacket(receiveDate, MAXSIZE);

            try {
                clientSocket.receive(serverReply);
                Date time2 = new Date();
                double timeStampEnd = time2.getTime();
                double RTT = timeStampEnd - timeStampStart;
                if(MinRTT == 0) {
                    MinRTT = RTT;
                }
                totalRTT += RTT;
                count++;
                System.out.println("ping to " + args[0] + ", seq = " + i + ", rtt = " + RTT + " ms");

                if(RTT > MaxRTT) {
                    MaxRTT = RTT;
                } else if (RTT < MinRTT) {
                    MinRTT = RTT;
                }
                Thread.sleep(1000);
            } catch (Exception e) {
                System.out.println("ping to " + args[0] + ", seq = " + i + ", rtt = time out");
                Thread.sleep(1000);
            }
        }
        long AverageRTT = Math.round(totalRTT / count);
        System.out.println("Average RTT = " + AverageRTT + " ms" + ", Minimum RTT = " + MinRTT + " ms" + ", Maximum RTT = " + MaxRTT + " ms.");
        clientSocket.close();

    }

}